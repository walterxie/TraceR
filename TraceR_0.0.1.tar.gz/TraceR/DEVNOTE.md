# Developer Note

RStudio Version 1.2.5033

Menu `Build` => `Build Source Package`

```R
remove.packages("TraceR")
install.packages("TraceR_0.0.0.9000.tar.gz", repos = NULL, type = "source")
library("TraceR")
```

